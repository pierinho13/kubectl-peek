kubectl-peek temporary namespace shell

Replace:
  cmd/namespace.go
  internal/kubernetes/context_namespace.go

Add:
  internal/kubernetes/namespace_shell.go
  internal/kubernetes/namespace_shell_test.go

Format and test:
  gofmt -w cmd/namespace.go \
    internal/kubernetes/context_namespace.go \
    internal/kubernetes/namespace_shell.go \
    internal/kubernetes/namespace_shell_test.go

  go test ./...
  go build -o kubectl-peek .

Usage:
  ./kubectl-peek namespace --shell
  ./kubectl-peek ns --shell
  ./kubectl-peek namespace traefik --shell

Persistent mode remains unchanged:
  ./kubectl-peek namespace

The temporary mode:
- loads the effective merged kubeconfig;
- preserves all clusters, users, contexts and exec plugins;
- flattens certificate/key paths into embedded data;
- changes only the selected context namespace;
- writes a mode 0600 temporary kubeconfig;
- opens an interactive child shell;
- prefixes the zsh/bash prompt;
- deletes all temporary files after exit;
- does not modify the source kubeconfig.
